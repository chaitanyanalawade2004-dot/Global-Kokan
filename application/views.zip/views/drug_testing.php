 <section class="page-title-layout3 page-title-light text-center pb-0 bg-overlay bg-parallax">
  <div class="bg-img"><img src="<?= base_url();?>assets/img/drugs.jpg" alt="background"></div>
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-lg-12 col-xl-6 offset-xl-3">
        <div class="pagetitle-categorey"><a href="#">Services</a> </div>
        <h1 class="pagetitle-heading">Drug Testing </h1>

      </div><!-- /.col-xl-6 -->
    </div><!-- /.row -->
  </div><!-- /.container -->
  <div class="breadcrumb-area">
    <div class="container">
      <nav>
        <ol class="breadcrumb justify-content-center mb-0">
          <li class="breadcrumb-item">
            <a href="<?= base_url()?>"><i class="icon-home"></i> <span>Home</span></a>
          </li>
          <li class="breadcrumb-item">
            <a href="<?= base_url('services');?>">Services</a>
          </li>
          <li class="breadcrumb-item active" aria-current="page">Drug Testing 
          </li>
        </ol>
      </nav>
    </div><!-- /.container -->
  </div><!-- /.breadcrumb-area -->
</section><!-- /.page-title -->


<section class=" pb-80">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-lg-8 offset-lg-2">
        <div class="text-block mb-50">
          <div class="row">
            <div class="col-lg-6">
              <p class="text-block-desc mb-20 text-justify">
              Drug testing is a process used to detect the presence of drugs or their metabolites in a person's body. It is commonly used in a variety of settings, including workplaces, schools, and criminal justice systems. Put your family and your client's health first and schedule a Drug Testing today. Our job is to make your job easier. </p>
            </div>
            <div class="col-lg-3">
              <img src="<?= base_url();?>assets/img/3.png" class="img-fluid">
            </div>

            <div class="col-lg-3">
             <img src="<?= base_url();?>assets/img/2.png" class="img-fluid">
           </div>

           <div class="col-lg-12">
             <p class="text-block-desc mb-20  text-justify">
              We provide drug and alcohol testing solutions that are convenient and tailored to meet your needs. Regular visits allow you to keep on top of your medical needs and ensure you are always compliant when it comes to the important matter of your wellbeing and employment. We are here for all your testing needs at school, home, work, etc. call us today!
            </p>
          </div>
        </div>
      </div><!-- /.text-block -->
    </div><!-- /.col-lg-8 -->
  </div><!-- /.row -->
</div><!-- /.container -->
</section>