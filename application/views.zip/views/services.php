
    <section class="page-title-layout2 page-title-light text-center pb-0 bg-overlay bg-parallax">
      <div class="bg-img"><img src="assets/images/page-titles/15.jpg" alt="background"></div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6 offset-xl-3">
            <h1 class="pagetitle-heading">Services</h1>
          </div><!-- /.col-xl-6 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
      <div class="breadcrumb-area">
        <div class="container">
          <nav>
            <ol class="breadcrumb justify-content-center mb-0">
              <li class="breadcrumb-item">
                <a href=""<?= base_url();?>"><i class="icon-home"></i> <span>Home</span></a>
              </li>
              <li class="breadcrumb-item active" aria-current="page">Services</li>
            </ol>
          </nav>
        </div><!-- /.container -->
      </div><!-- /.breadcrumb-area -->
    </section><!-- /.page-title -->

    <!-- ======================
      Blog Grid
    ========================= -->
    <section class="fancybox-layout1 pb-0">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3">
            <div class="heading text-center mb-50">
              <h2 class="heading-subtitle">Commitment to Quality</h2>
              <h3 class="heading-title">We Bring Diagnostic Testing and Drug Development Together!</h3>
            </div>
          </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
        <div class="row">
          <!-- fancybox item #1 -->
          <div class="col-sm-6 col-d-3 col-lg-3">
            <div class="fancybox-item">
              <div class="fancybox-icon">
                <i class="icon-education4 icon-item"></i>
              </div><!-- /.fancybox-icon -->
              <div class="fancybox-body">
                <h4 class="fancybox-title">Drug testing</h4>
               
                <a href="<?= base_url('services/drug-testing');?>" class="btn btn-link btn-primary">
                  <i class="plus-icon">+</i>
                  <span>Read More</span>
                </a>
              </div><!-- /.fancybox-body -->
            </div><!-- /.fancybox-item -->
          </div><!-- /.col-lg-4 -->
          <!-- fancybox item #2 -->
          <div class="col-sm-6 col-d-3 col-lg-3">
            <div class="fancybox-item">
              <div class="fancybox-icon">
                <i class='fas fa-virus' style='font-size:60px'></i>
              </div><!-- /.fancybox-icon -->
              <div class="fancybox-body">
                <h4 class="fancybox-title"> Covid 19 testing</h4>
               
                <a href="<?= base_url('services/covid-19-testing');?>" class="btn btn-link btn-primary">
                  <i class="plus-icon">+</i>
                  <span>Read More</span>
                </a>
              </div><!-- /.fancybox-body -->
            </div><!-- /.fancybox-item -->
          </div><!-- /.col-lg-4 -->
          <!-- fancybox item #3 -->
          <div class="col-sm-6 col-d-3 col-lg-3">
            <div class="fancybox-item">
              <div class="fancybox-icon">
                <i class="icon-search icon-item"></i>
              </div><!-- /.fancybox-icon -->
              <div class="fancybox-body">
                <h4 class="fancybox-title">Background checks</h4>
                
                <a href="<?= base_url('services/background-checks');?>" class="btn btn-link btn-primary">
                  <i class="plus-icon">+</i>
                  <span>Read More</span>
                </a>
              </div><!-- /.fancybox-body -->
            </div><!-- /.fancybox-item -->
          </div><!-- /.col-lg-4 -->
          <!-- fancybox item #4 -->
          <div class="col-sm-6 col-d-3 col-lg-3">
            <div class="fancybox-item">
              <div class="fancybox-icon">
                <i class="icon-biology6 icon-item"></i>
              </div><!-- /.fancybox-icon -->
              <div class="fancybox-body">
                <h4 class="fancybox-title">DNA Testing</h4>
               
                <a href="<?= base_url('services/dna-testing');?>" class="btn btn-link btn-primary">
                  <i class="plus-icon">+</i>
                  <span>Read More</span>
                </a>
              </div><!-- /.fancybox-body -->
            </div><!-- /.fancybox-item -->
          </div><!-- /.col-lg-4 -->
          <!-- fancybox item #5 -->
         
        </div><!-- /.row -->
      
      </div><!-- /.container -->
    </section><!-- /.fancybox-layout1 -->
<br>