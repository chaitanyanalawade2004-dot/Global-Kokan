
    <section class="map py-0">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2983.4619850368163!2d-86.69731958517097!3d41.60252057924501!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x881113ae6daa11f9%3A0x3027a45b80e6ef16!2s408%20Legacy%20Plaza%20W%2C%20La%20Porte%2C%20IN%2046350%2C%20USA!5e0!3m2!1sen!2sin!4v1674922218540!5m2!1sen!2sin" height="620" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

      <div class="map-container">
        <div class="contact-panel p-0">
          <div class="panel-header">
            <h3 class="panel-title color-white mb-0">Lab Address</h3>
          </div>
          <div class="accordion" id="accordion">
            <div class="accordion-item opened">
              <div class="accordion-header" data-toggle="collapse" data-target="#collapse1">
                <a class="accordion-title" href="#">LA PORTE</a>
              </div><!-- /.accordion-item-header -->
              <div id="collapse1" class="collapse show" data-parent="#accordion">
                <div class="accordion-body">
                  <ul class="contact-list list-unstyled mb-0">
                    <li>Phone: 219-210-5867</li>
                    <li>Email: arkhamlabcollections@gmail.com</li>
                    <li>Address: 408 Legacy Plaza W, La Porte, IN 46350</li>
                    <li>Hours: Mon-Fri: 8am – 7pm</li>
                  </ul>
                </div><!-- /.accordion-item-body -->
              </div>
            </div><!-- /.accordion-item -->
          
          </div><!-- /.accordion -->
        </div>
      </div><!-- /.map-container -->
    </section><!-- /.GoogleMap -->

    <!-- ==========================
        contact layout 1
    =========================== -->
    <section class="contact-layout1">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-7">
            <div class="heading-layout2 mb-50">
              <h2 class="heading-subtitle">Contact Us And We Will Respond Within The Next Two Working Days</h2>
              <h3 class="heading-title">Get In Touch With Your Nearest Local Health Business Sales Executive
              </h3>
            </div>
          </div><!-- /.col-lg-7 -->
        </div><!-- /.row -->
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-4">
            <div class="text-block">
              <p class="text-block-desc">Depending on the nature of your enquiry, the customer care centre staff will
                then
                distribute your request for consultation to the appropriate Laboratory Medicine discipline.</p>
              <p class="text-block-desc">A member of the Medical/Scientific Staff will get back to the requesting
                healthcare provider within one business day.
              </p>
            </div>
            
          </div><!-- /.col-lg-4 -->
          <div class="col-sm-12 col-md-12 col-lg-8">
            <form class="contact-panel-form" method="post" action="" id="contactForm">
              <div class="row">
                <div class="col-sm-12 col-md-4 col-lg-4">
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Name" id="contact-name" name="contact-name"
                      required>
                  </div>
                </div><!-- /.col-lg-4 -->
                <div class="col-sm-12 col-md-4 col-lg-4">
                  <div class="form-group">
                    <input type="email" class="form-control" placeholder="Email" id="contact-email" name="contact-email"
                      required>
                  </div>
                </div><!-- /.col-lg-4 -->
                <div class="col-sm-12 col-md-4 col-lg-4">
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Phone" id="contact-Phone" name="contact-phone"
                      required>
                  </div>
                </div><!-- /.col-lg-4 -->
                <div class="col-12">
                  <div class="form-group">
                    <textarea class="form-control" placeholder="Additional Details" id="contact-message"
                      name="contact-message"></textarea>
                  </div>
                  <button type="submit" class="btn btn-secondary  btn-block btn-xhight mt-10">
                    <span>Submit Request</span> <i class="icon-arrow-right"></i>
                  </button>
                  <div class="contact-result"></div>
                </div><!-- /.col-lg-12 -->
              </div><!-- /.row -->
            </form>
          </div><!-- /.col-lg-8 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.contact layout 1 -->

    