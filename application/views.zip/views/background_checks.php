 <section class="page-title-layout3 page-title-light text-center pb-0 bg-overlay bg-parallax">
  <div class="bg-img"><img src="<?= base_url();?>assets/img/check.jpg" alt="background"></div>
  <div class="container">
    <div class="row">
      <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6 offset-xl-3">
        <div class="pagetitle-categorey"><a href="#">Services</a> </div>
        <h1 class="pagetitle-heading">Background Check
        </h1>
      </div><!-- /.col-xl-6 -->
    </div><!-- /.row -->
  </div><!-- /.container -->
  <div class="breadcrumb-area">
    <div class="container">
      <nav>
        <ol class="breadcrumb justify-content-center mb-0">
          <li class="breadcrumb-item">
            <a href="<?= base_url()?>"><i class="icon-home"></i> <span>Home</span></a>
          </li>
          <li class="breadcrumb-item">
            <a href="<?= base_url('services');?>">Services</a>
          </li>
          <li class="breadcrumb-item active" aria-current="page">Background Check
          </li>
        </ol>
      </nav>
    </div><!-- /.container -->
  </div><!-- /.breadcrumb-area -->
</section><!-- /.page-title -->


<section class=" pb-80">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-lg-8 offset-lg-2">
        <div class="text-block mb-50">

          <div class="row">
            <div class="col-lg-8">
              <p class="text-block-desc mb-20">
                Hiring the right person requires more than screening for drugs. You need assurance that the person you are about to hire has a clear background as well as a clear drug screen. Arkham Laboratory Collections can provide answers to theses important safety & background questions:  

                <ul>
                  <li>Do they have a criminal history?  </li>
                  <li>Do they have a clean driving record? </li>
                  <li>Have they been truthful about current and past living locations? </li>
                  <li>Are they a sex offender? </li>
                  <li>Do they have a record of violent?</li>
                </ul>
              </p>
            </div>
            <div class="col-lg-4 text-center">
              <img src="<?= base_url();?>assets/img/1.png" class="img-fluid" width="80%">
            </div>
            <div class="col-lg-8">
             <p class="text-block-desc mb-20  text-justify">
              <ul>
                <li> <b> Background check- Nationwide Criminal Database </b>
                - Multi-jurisdictional search of millions of state and county records. Database is compiled from counties, department of corrections and administrative courts.</li>

                <li> <b>Social Security Address Trace </b>
                - Reveals address history based on credit applications, utility bills, and similar filings. </li>


                <li><b>Nationwide Sex Offender Registry</b>
                - Search of the National Sex Offender Registry  </li>

                <li><b>Motor Vehicle Report (MVR) </b>
                  - License class, status, violations, and accidents. Excludes any pass-through fees.
                </li>
              </ul>

            </p>
          </div>
          <div class="col-lg-4">
           <img src="<?= base_url();?>assets/img/1_1.png" class="img-fluid" width="80%">
         </div>

       </div>
     </div>
   </div><!-- /.col-lg-8 -->
 </div><!-- /.row -->
</div><!-- /.container -->
</section>