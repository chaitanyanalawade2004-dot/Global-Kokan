
    <section class="page-title-layout2 page-title-light text-center pb-0 bg-overlay bg-parallax">
      <div class="bg-img"><img src="assets/img/about.jpeg" alt="background"></div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6 offset-xl-3">
            <h1 class="pagetitle-heading">About Us</h1>
          </div><!-- /.col-xl-6 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
      <div class="breadcrumb-area">
        <div class="container">
          <nav>
            <ol class="breadcrumb justify-content-center mb-0">
              <li class="breadcrumb-item">
                <a href=""<?= base_url();?>"><i class="icon-home"></i> <span>Home</span></a>
              </li>
              <li class="breadcrumb-item active" aria-current="page">About Us</li>
            </ol>
          </nav>
        </div><!-- /.container -->
      </div><!-- /.breadcrumb-area -->
    </section><!-- /.page-title -->


    <!-- ========================
      About Layout 1
    =========================== -->
    <section class="about-layout1 pb-0">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-10 col-lg-10 col-xl-7" >
            <div class="heading-layout2">
              <h2 class="heading-subtitle color-body">Excellence, Dedicated, and Experienced Laboratory Technologists
              </h2>
              <h3 class="heading-title mb-50">A Trusted Healthcare Partner Providing You With High Quality Test
                Services to Manage All Health Effectively!</h3>
            </div><!-- /heading -->
            <div class="about-img">
              <div class="about-badge">
                <div class="about-icon"><i class="icon-beaker"></i></div>
              </div>
              <img src="assets/images/about/1.png" alt="about" class="w-100">
            </div>
          </div><!-- /.col-12 -->
          <div class="col-sm-12 col-md-10 col-lg-10 col-xl-5">
            <div class="about-Text">
              <p class="mb-30" style="text-align:justify;">Arkham Laboratory Collections is a full service laboratory collection company. We are a drug testing facility that offers many services including DNA, Covid, and background checks tailored to the transportation, medical, public service, school administration, manufacturing, and hospitality industry.
              </p>
             
              <div class="d-flex flex-wrap align-items-center mb-30">
                <a href="<?= base_url('book-lab-visit');?>" class="btn btn-secondary btn-xl mr-30">
                  <span>Book a Home Visit</span>
                  <i class="icon-arrow-right"></i>
                </a>
                <img src="assets/images/about/singnture.png" alt="singnture">
              </div>
              <ul class="features-list list-unstyled mb-0">
               
                <li class="feature-item">
                  <i class="feature-icon"></i>
                  <h4 class="feature-title mb-0">97% customer satisfaction rate</h4>
                </li>
              
              </ul>
            </div>
          </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.About Layout 1 -->

    <!-- ========================
     Banner Layout 1
    =========================== -->
    <section class="banner-layout1 py-0">
      <div class="top-shape"></div>
      <div class="container-fluid">
        <div class="row">
          <div class="col-12 col-xl-6 banner-content">
            <div class="banner-text">
              <div class="heading-layout2 heading-light">
                <h3 class="heading-title">
                  </h3>
                <p class="heading-desc mb-40">
                As NORTHWEST INDIANA'S LEADING DRUG TESTING PROVIDER we offer quality and professional testing services. Our Testing services are accurate, affordable, confidential and guaranteed results. <br><br> We're committed to providing a superior level of service for our clients. we feel that we are unmatched in customer care and we work hard daily to ensure your experience with our staff is always pleasant.  We value integrity, professionalism and confidentiality, while guaranteeing our client’s needs are first and foremost. Our goal is to help you ensure your company’s productivity and be committed to help develop solutions for payers, clinicians and organizations involved with substance use disorder, pain management and criminal justice agencies.
                </p>
              </div>
              
              <div class="fancybox-layout2 fancybox-light">
                <div class="fancybox-item">
                  <div class="fancybox-icon">
                    <i class="icon-avatar2"></i>
                  </div><!-- /.fancybox-icon -->
                  <div class="fancybox-body">
                    <h4 class="fancybox-title">Patient Centered Care </h4>
                    <p class="fancybox-desc">We work day and night to solve the problems that can help them move
                      forward for those who is seeking answers!</p>
                  </div><!-- /.fancybox-body -->
                </div><!-- /.fancybox-item -->
                <div class="fancybox-item">
                  <div class="fancybox-icon">
                    <i class="icon-allotropy"></i>
                  </div><!-- /.fancybox-icon -->
                  <div class="fancybox-body">
                    <h4 class="fancybox-title">Quality Improvement </h4>
                    <p class="fancybox-desc">Our team typically processes over 300  Patients Every Month</p>
                  </div><!-- /.fancybox-body -->
                </div><!-- /.fancybox-item -->
              </div><!-- /.fancybox-layout2 -->
            </div><!-- /.banner-text -->
          </div><!-- /.col-lg-6 -->
          <div class="col-12 col-xl-6 banner-img d-flex align-items-center">
            <div class="bg-img">
              <img src="assets/img/about3.jpg" alt="backgrounds">
            </div>
            <div class="banner-shape"></div>
          </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.Banner Layout 1 -->
<br>
   
 