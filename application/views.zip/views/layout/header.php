<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />
  <meta name="description" content="">
  <link href="<?= base_url();?>assets/images/favicon/favicon.png" rel="icon">
  <title>Lab</title>

  <link
    href="https://fonts.googleapis.com/css2?family=Titillium+Web:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700&amp;display=swap"
    rel="stylesheet">
  <link rel="stylesheet" href="<?= base_url();?>assets/css/all.css">
  <link rel="stylesheet" href="<?= base_url();?>assets/css/libraries.css">
  <link rel="stylesheet" href="<?= base_url();?>assets/css/style.css">
</head>

<body>
  <div class="wrapper">
    <div class="preloader">
      <div class="loading"><span></span><span></span><span></span><span></span></div>
    </div><!-- /.preloader -->

    <!-- =========================
        Header
    =========================== -->
    <header class="header header-layout1">
      <div class="header-topbar">
        <div class="container-fluid">
          <div class="row align-items-center">
            <div class="col-12">
              <div class="d-flex align-items-center justify-content-between">
                <ul class="contact-list d-flex flex-wrap align-items-center list-unstyled mb-0">
                  <li class="miniPopup-language-area">
                    <button class="miniPopup-language-trigger" type="button" style="background:#252775"></button>
                    
                  </li>
                
                  <li>
                    <i class="icon-location"></i><a href="#">408 Legacy Plaza W, La Porte, IN 46350</a>
                  </li>
                  <li>
                    <i class="icon-clock"></i><a href="#">Mon - Fri: 8:00 am - 7:00 pm</a>
                  </li>
                </ul><!-- /.contact-list -->
                <div class="d-flex">
                  <ul class="social-icons list-unstyled mb-0 mr-30">
                    <li><a href="https://www.facebook.com/ArkhamLaboratoryCollections" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="https://www.instagram.com/ARKHAMLABCOLLECTIONS/" target="_blank"><i class="fab fa-instagram" ></i></a></li>
                  </ul><!-- /.social-icons -->
                 
                </div>
              </div>
            </div><!-- /.col-12 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </div><!-- /.header-top -->
      <nav class="navbar navbar-expand-lg sticky-navbar">
        <div class="container-fluid">
          <a class="navbar-brand" href="<?= base_url();?>">
            <img src="<?= base_url();?>assets/images/logo.jpg" class="logo-dark" alt="logo" width="65%">
          </a>
          <button class="navbar-toggler" type="button">
            <span class="menu-lines"><span></span></span>
          </button>
          <div class="collapse navbar-collapse justify-content-center" id="mainNavigation">
            <ul class="navbar-nav">
               <li class="nav-item">
                 <a href="<?= base_url();?>" class="nav-item-link">Home</a>
              </li>
              <li class="nav-item">
                 <a href="<?= base_url('about-us');?>" class="nav-item-link">About us</a>
              </li>
              <li class="nav-item">              
                 <a href="<?= base_url('services');?>" class="nav-item-link">Services</a>
               </li>
               <li class="nav-item"> 
                <a href="<?= base_url('contact');?>" class="nav-item-link">Contacts</a>
              </li>

            </ul><!-- /.navbar-nav -->
            <ul class="header-actions d-flex align-items-center position-relative list-unstyled mb-0">
              <li class="d-none d-xl-flex align-items-center">
                <a href="<?= base_url('book-lab-visit');?>" class="btn btn-primary btn-outlined btn-contact">
                  Book a Lab Visit
                </a>
              </li>
             
            </ul>
            <button class="close-mobile-menu d-block d-lg-none"><i class="fas fa-times"></i></button>
          </div><!-- /.navbar-collapse -->
          <div class="d-none d-xl-flex align-items-center position-relative ml-30">
            <div class="contact-phone d-flex align-items-center">
              <div class="contact-icon"><i class="icon-chemical9"></i></div>
              <div>
                <span class="d-block">Call Us Now:</span>
                <a class="phone-link d-block" href="tel:219-210-5867">219-210-5867</a>
              </div>
            </div>
          </div>
        </div><!-- /.container -->
      </nav><!-- /.navabr -->
    </header><!-- /.Header -->