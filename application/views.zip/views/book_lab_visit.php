
<section class="page-title-layout1 page-title-light pb-0 bg-overlay bg-parallax">
      <div class="bg-img"><img src="assets/images/page-titles/13.jpg" alt="background"></div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6">
            <h1 class="pagetitle-heading">Book a Lab Visit</h1>
            <p class="pagetitle-desc">Your focus is on providing patients the best possible care and we’re here to
              help. To complement our comprehensive menu of tests, we provide resources to registered healthcare
              professionals to support your testing needs.
            </p>
           
          </div><!-- /.col-xl-6 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
      <div class="breadcrumb-area">
        <div class="container">
          <nav>
            <ol class="breadcrumb mb-0">
              <li class="breadcrumb-item">
                <a href=""<?= base_url();?>"><i class="icon-home"></i> <span>Home</span></a>
              </li>
              <li class="breadcrumb-item">
                <a href="#">Book Lab Visit </a>
              </li>
             
            </ol>
          </nav>
        </div><!-- /.container -->
      </div><!-- /.breadcrumb-area -->
    </section><!-- /.page-title -->

    <section class="pb-40">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-4">
            <aside class="sidebar has-marign-right sticky-top mb-50">
              <div class="widget widget-banner bg-overlay bg-overlay-secondary">
                <div class="bg-img"><img src="assets/images/banners/4.jpg" alt="background"></div>
                <div class="widget-content">
                  <h4 class="widget-title">Preparing for Your Test Help Ensure All Goes Smoothly. </h4>
                  <p class="widget-desc">To reduce your wait time, complete the personal information on the form in
                    advance most routine tests.
                  </p>
                  <a href="<?= base_url('contact');?>" class="btn btn-white btn-white-style2 btn-block mb-30">
                    <span>Looking for More Info!</span>
                    <i class="icon-arrow-right"></i>
                  </a>
                  <a href="tel:+201061245741" class="phone-number d-flex align-items-center">
                    <i class="icon-phone mr-20"></i> <span>219-210-5867</span>
                  </a>
                </div><!-- /.widget-content -->
              </div><!-- /.widget-banner -->
             
            </aside><!-- /.sidebar -->
          </div><!-- /.col-lg-4 -->
          <div class="col-sm-12 col-md-12 col-lg-8">
            <div class="contact-panel">
              <form class="contact-panel-form" id="contactForm">
                <div class="row">
                  <div class="col-sm-12">
                    <h4 class="contact-panel-title">Book a Lab Visit</h4>
                    <p class="contact-panel-desc mb-30">Please feel welcome to contact our friendly reception staff
                      with any general or medical enquiry.
                    </p>
                  </div>
                
                  <div class="col-sm-6 col-md-6 col-lg-6">
                    <div class="form-group">
                      <label for="name">Name (required)</label>
                      <input type="text" class="form-control" placeholder="Name" id="name" required>
                    </div>
                  </div><!-- /.col-lg-6 -->
                  <div class="col-sm-6 col-md-6 col-lg-6">
                    <div class="form-group">
                      <label for="email">Email</label>
                      <input type="email" class="form-control" placeholder="Email" id="email">
                    </div>
                  </div><!-- /.col-lg-6 -->
                  <div class="col-sm-4 col-md-4 col-lg-4">
                    <div class="form-group">
                      <label for="phone">Phone (required)</label>
                      <input type="text" class="form-control" placeholder="Phone" id="phone">
                    </div>
                  </div><!-- /.col-lg-4 -->
                  <div class="col-sm-4 col-md-4 col-lg-4">
                    <div class="form-group form-group-date">
                      <label for="date">Date (required)</label>
                      <input type="date" class="form-control" id="date" required>
                    </div>
                  </div><!-- /.col-lg-4 -->
                  <div class="col-sm-4 col-md-4 col-lg-4">
                    <div class="form-group form-group-date">
                      <label for="time">Time (required)</label>
                      <input type="time" class="form-control" id="time" required>
                    </div>
                  </div><!-- /.col-lg-4 -->
                  
                  <div class="col-sm-6 col-md-6 col-lg-6">
                    <div class="form-group">
                      <label for="city">City</label>
                      <input type="text" class="form-control" placeholder="Tanta" id="city">
                    </div>
                  </div><!-- /.col-lg-6 -->
                  <div class="col-sm-6 col-md-6 col-lg-6">
                    <div class="form-group">
                      <label for="zip">Zip</label>
                      <input type="text" class="form-control" placeholder="2468" id="zip">
                    </div>
                  </div><!-- /.col-lg-6 -->
                  <div class="col-12">
                    <div class="form-group">
                      <label for="details">Additional Details</label>
                      <textarea class="form-control" placeholder="Details" id="details" rows="6"></textarea>
                    </div>
                    <button type="submit" class="btn btn-secondary btn-block btn-xhight">
                      <span>Book Your Visit</span> <i class="icon-arrow-right"></i>
                    </button>
                  </div>
                </div><!-- /.row -->
              </form>
            </div>
          </div><!-- /.col-lg-8 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section>

    <!-- ========================
     Banner Layout 3
    =========================== -->
    <section class="banner-layout3 py-0">
      <div class="top-shape"></div>
      <div class="container-fluid">
        <div class="row">
          <div class="col-12 col-xl-6 banner-img d-flex align-items-center">
            <div class="bg-img">
              <img src="assets/img/about3.jpg" alt="backgrounds">
            </div>
            <div class="banner-shape"></div>
          </div><!-- /.col-lg-6 -->
          <div class="col-12 col-xl-6 banner-content">
            <div class="banner-text">
              <div class="heading-layout2 heading-light">
                <h3 class="heading-title">We are Helping to Advance Health with Clinical Trials and Vaccines
                  Development.</h3>
                <p class="heading-desc mb-40">We believe in harnessing science for human good, so we work day and
                  night, around the world, to deliver answers for health questions.
                </p>
              </div>
              <div class="fancybox-layout2 fancybox-light">
                <div class="fancybox-item">
                  <div class="fancybox-icon">
                    <i class="icon-chemistry"></i>
                  </div><!-- /.fancybox-icon -->
                  <div class="fancybox-body">
                    <h4 class="fancybox-title">World Class Diagnostics</h4>
                    <p class="fancybox-desc">We have developed some of the world's most advanced testing capabilities
                      to help improve health and lives.</p>
                  </div><!-- /.fancybox-body -->
                </div><!-- /.fancybox-item -->
                <div class="fancybox-item">
                  <div class="fancybox-icon">
                    <i class="icon-drug"></i>
                  </div><!-- /.fancybox-icon -->
                  <div class="fancybox-body">
                    <h4 class="fancybox-title">Leader in Drug Development</h4>
                    <p class="fancybox-desc">With the support of our diagnostics capabilities to deliver drug trials
                      that are both reliable and rigorous.</p>
                  </div><!-- /.fancybox-body -->
                </div><!-- /.fancybox-item -->
              </div><!-- /.fancybox-layout2 -->
              
            </div><!-- /.banner-text -->
          </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.Banner Layout3 -->

    <!-- ======================
     Work Process 
    ========================= -->
    <section class="work-process">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <h2 class="heading-subtitle">How to Order and Prepare for a Test!</h2>
          </div><!-- /.col-12 -->
          <div class="col-sm-12 col-md-12 col-lg-6 col-xl-5">
            <h3 class="heading-title">Preparing for Your Test Help Ensure All Goes Smoothly</h3>
          </div><!-- /.col-xl-5 -->
          <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 offset-xl-1">
           
            <p class="heading-desc mb-30">we connect directly with patients to deliver their results so they have
              valuable
              health information when they need it most, we care about our people.
            </p>
            <ul class="features-list list-horizontal bg-transparent list-unstyled p-0 mb-60">
              
              <li class="feature-item">
                <i class="feature-icon"></i>
                <h4 class="feature-title mb-0">97% customer satisfaction rate</h4>
              </li>
             
            </ul>
          </div><!-- /.col-xl-6 -->
        </div><!-- /.row -->
        <div class="row">
          <!-- process item #1 -->
         
          <!-- process item #2 -->
          <div class="col-sm-6 col-md-6 col-lg-6 col-xl-4">
            <div class="process-item">
              <span class="process-number">01.</span>
              <div class="process-icon">
                <i class="icon-chemical5"></i>
              </div><!-- /.process-icon -->
              <h4 class="process-title">Make an Appointment</h4>
              <p class="process-desc">You can book an appointment online or contact us to send you one of our lab
                experts</p>
             
            </div><!-- /.process-item -->
          </div><!-- /.col-lg-3-->
          <!-- process item #3 -->
          <div class="col-sm-6 col-md-6 col-lg-6 col-xl-4">
            <div class="process-item">
              <span class="process-number">02.</span>
              <div class="process-icon">
                <i class="icon-chemical8"></i>
              </div><!-- /.process-icon -->
              <h4 class="process-title">Collect a Sample</h4>
              <p class="process-desc">Samples can be collected in our office or mobile, a lab, or the patient can collect the
                sample at home.
              </p>
             
            </div><!-- /.process-item -->
          </div><!-- /.col-lg-3-->
          <!-- process item #4 -->
          <div class="col-sm-6 col-md-6 col-lg-6 col-xl-4">
            <div class="process-item">
              <span class="process-number">03.</span>
              <div class="process-icon">
                <i class="icon-archive"></i>
              </div><!-- /.process-icon -->
              <h4 class="process-title">Get Your Results</h4>
              <p class="process-desc">Results are available for most tests within 48-72 hours of samples reaching the lab.
              </p>
             
            </div><!-- /.process-item -->
          </div><!-- /.col-lg-3-->
        </div><!-- /.row -->
       
      </div><!-- /.container -->
    </section><!-- /.Work Process -->


