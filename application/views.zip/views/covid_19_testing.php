 <section class="page-title-layout3 page-title-light text-center pb-0 bg-overlay bg-parallax">
  <div class="bg-img"><img src="<?= base_url();?>assets/images/page-titles/15.jpg" alt="background"></div>
  <div class="container">
    <div class="row">
      <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6 offset-xl-3">
        <div class="pagetitle-categorey"><a href="#">Services</a> </div>
        <h1 class="pagetitle-heading">COVID-19 <br>
        Novel Coronavirus </h1>
        
      </div><!-- /.col-xl-6 -->
    </div><!-- /.row -->
  </div><!-- /.container -->
  <div class="breadcrumb-area">
    <div class="container">
      <nav>
        <ol class="breadcrumb justify-content-center mb-0">
          <li class="breadcrumb-item">
            <a href="<?= base_url()?>"><i class="icon-home"></i> <span>Home</span></a>
          </li>
          <li class="breadcrumb-item">
            <a href="<?= base_url('services');?>">Services</a>
          </li>
          <li class="breadcrumb-item active" aria-current="page"> COVID-19
          </li>
        </ol>
      </nav>
    </div><!-- /.container -->
  </div><!-- /.breadcrumb-area -->
</section><!-- /.page-title -->


<section class=" pb-80">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-lg-8 offset-lg-2">
        <div class="text-block mb-50">
          <p class="text-block-desc mb-20 text-justify">
           
            Arkham Laboratory Collections is proud to be offering SARS-CoV-2 (COVID-19) testing. <br><br>

            COVID-19 PCR testing acceptable for traveling, cruises, and medical surgeries
            <br><br>
            COVID-19 can run ramped when unchecked!live in nursing facilities is where Covid can become extremely dangerous. regular Covid testing in medical settings can help prevent love ones from suffering and becoming ill. 
            <br><br>
            COVID-19 it’s something sadly that seems like it’s here to stay! Better than wish it away be prepared for it. The workplace is where everyone spends most of their day which means the most common place to infect or become infected by others. Just like a random drug screen in order to keep your employees and everyone around them safe COVID-19 testing is something that should be checked regularly also. When doing pre-employment checks COVID-19 testing should be a big part of that along with the drug testing and the background portion. By implementing regular COVID-19 testing in the workplace you’re helping stop the spread of a virus and ensuring everyone’s safety.
          </p>
        </div><!-- /.text-block -->
      </div><!-- /.col-lg-8 -->
    </div><!-- /.row -->
  </div><!-- /.container -->
</section>