

    <section class="slider">
      <div class="slick-carousel carousel-dots-light m-slides-0"
        data-slick='{"slidesToShow": 1,"autoplay": true, "arrows": true, "dots": true, "speed": 700,"fade": true,"cssEase": "linear"}'>
        <div class="slide-item bg-overlay align-v-h">
          <div class="bg-img"><img src="<?= base_url();?>assets/images/sliders/1.jpg" alt="slide img"></div>
          <div class="container">
            <div class="row align-items-center">
              <div class="col-sm-12 col-md-12 col-lg-12 col-xl-7">
                <div class="slide-content">
                  <span class="slide-subtitle">Excellence, Dedicated, and Experienced Laboratory Technologists!</span>
                  <h2 class="slide-title">Arkham Laboratory Collections</h2>
                  <p class="slide-desc">We are continually harnessing our medical expertise to build best test offering
                    while investing in technology to transform the delivery of health care.</p>
                  <div class="d-flex flex-wrap align-items-center">
                    <a href="<?= base_url('book-lab-visit');?>" class="btn btn-white btn-white-style2 mr-30">
                      <span>Book a Home Visit</span>
                      <i class="icon-arrow-right"></i>
                    </a>
                    <a href="<?= base_url('services');?>" class="btn btn-white btn-outlined">
                      <span>Tests and Services</span>
                    </a>
                  </div>
                </div><!-- /.slide-content -->
              </div><!-- /.col-xl-7 -->
              <div class="col-sm-12 col-md-12 col-lg-12 col-xl-4 offset-xl-1">
                <div class="fancybox-layout5 p-0 m-0">
                  <div class="fancybox-container">
                    <!-- fancybox item #1 -->
                    <div class="fancybox-item">
                      <div class="fancybox-body">
                        <div class="fancybox-icon">
                          <i class="icon-chemical5"></i>
                        </div><!-- /.fancybox-icon -->
                        <h4 class="fancybox-title">New Advanced Instruments</h4>
                      </div><!-- /.fancybox-body -->
                    </div><!-- /.fancybox-item -->
                    <!-- fancybox item #2 -->
                    <div class="fancybox-item">
                      <div class="fancybox-body">
                        <div class="fancybox-icon">
                          <i class="icon-chemical2"></i>
                        </div><!-- /.fancybox-icon -->
                        <h4 class="fancybox-title">Strict Quality Practices</h4>
                      </div><!-- /.fancybox-body -->
                    </div><!-- /.fancybox-item -->
                    <!-- fancybox item #3 -->
                    <div class="fancybox-item">
                      <div class="fancybox-body">
                        <div class="fancybox-icon">
                          <i class="icon-archive"></i>
                        </div><!-- /.fancybox-icon -->
                        <h4 class="fancybox-title">Customized Lab Solutions</h4>
                      </div><!-- /.fancybox-body -->
                    </div><!-- /.fancybox-item -->
                  </div><!-- /.fancybox-container -->
                </div><!-- /.fancybox-layout5 -->
              </div><!-- /.col-xl-3 -->
            </div><!-- /.row -->
          </div><!-- /.container -->
        </div><!-- /.slide-item -->
        <div class="slide-item bg-overlay align-v-h">
          <div class="bg-img"><img src="<?= base_url();?>assets/images/sliders/2.jpg" alt="slide img"></div>
          <div class="container">
            <div class="row align-items-center">
              <div class="col-sm-12 col-md-12 col-lg-12 col-xl-7">
                <div class="slide-content">
                  <span class="slide-subtitle">Excellence, Dedicated, and Experienced Laboratory Technologists!</span>
                  <h2 class="slide-title">Quality Laboratory Testing Services!</h2>
                  <p class="slide-desc">We are continually harnessing our medical expertise to build best test offering
                    while investing in technology to transform the delivery of health care.</p>
                  <div class="d-flex flex-wrap align-items-center">
                    <a href="<?= base_url('book-lab-visit');?>" class="btn btn-white btn-white-style2 mr-30">
                      <span>Book a Home Visit</span>
                      <i class="icon-arrow-right"></i>
                    </a>
                    <a href="<?= base_url('services');?>" class="btn btn-white btn-outlined">
                      <span>Tests and Services</span>
                    </a>
                  </div>
                </div><!-- /.slide-content -->
              </div><!-- /.col-xl-7 -->
              <div class="col-sm-12 col-md-12 col-lg-12 col-xl-4 offset-xl-1">
                <div class="fancybox-layout5 p-0 m-0">
                  <div class="fancybox-container">
                    <!-- fancybox item #1 -->
                    <div class="fancybox-item">
                      <div class="fancybox-body">
                        <div class="fancybox-icon">
                          <i class="icon-chemical5"></i>
                        </div><!-- /.fancybox-icon -->
                        <h4 class="fancybox-title">New Advanced Instruments</h4>
                      </div><!-- /.fancybox-body -->
                    </div><!-- /.fancybox-item -->
                    <!-- fancybox item #2 -->
                    <div class="fancybox-item">
                      <div class="fancybox-body">
                        <div class="fancybox-icon">
                          <i class="icon-chemical2"></i>
                        </div><!-- /.fancybox-icon -->
                        <h4 class="fancybox-title">Strict Quality Practices</h4>
                      </div><!-- /.fancybox-body -->
                    </div><!-- /.fancybox-item -->
                    <!-- fancybox item #3 -->
                    <div class="fancybox-item">
                      <div class="fancybox-body">
                        <div class="fancybox-icon">
                          <i class="icon-archive"></i>
                        </div><!-- /.fancybox-icon -->
                        <h4 class="fancybox-title">Customized Lab Solutions</h4>
                      </div><!-- /.fancybox-body -->
                    </div><!-- /.fancybox-item -->
                  </div><!-- /.fancybox-container -->
                </div><!-- /.fancybox-layout5 -->
              </div><!-- /.col-xl-3 -->
            </div><!-- /.row -->
          </div><!-- /.container -->
        </div><!-- /.slide-item -->
      </div><!-- /.carousel -->
    </section><!-- /.slider -->

    <!-- ========================
      About Layout 2
    =========================== -->
    <section class="about-layout2 pt-130 pb-130">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-10 col-lg-8 col-xl-8">
            <div class="about-text mb-30">
              <div class="about-badge">
                <div class="about-icon"><i class="icon-beaker"></i></div>
              </div>
              <div class="about-text-banner">
                <div class="heading-layout2">
                  <h3 class="heading-title mb-0">A Trusted Healthcare Partner Providing You With High Quality Test
                    Services to Manage All Health Effectively!</h3>
                </div>
              </div>
            </div>
            <div class="about-img d-flex justify-content-end">
              <img src="<?= base_url();?>assets/images/about/2.png" alt="about">
            </div>
          </div><!-- /.col-12 -->
          <div class="col-sm-12 col-md-10 col-lg-8 col-xl-4">
            <div class="about-Text">
              <p class="mb-30">Arkham Laboratory Collections is a full service laboratory collection company. We are a drug testing facility that offers many services  including DNA, Covid, and background checks tailored to the transportation, medical, public service, school administration, manufacturing, and hospitality industry.
              </p>
              <ul class="features-list-layout2 list-unstyled mb-40">
               
                <li class="feature-item">
                  <i class="feature-icon"></i>
                  <h4 class="feature-title mb-0">97% customer satisfaction rate</h4>
                </li>
               
              </ul>
              <p class="mb-30">While we believe we are more than just numbers, the depth of our laboratories is pretty
                impressive.</p>
              <div class="author-meta d-flex flex-wrap align-items-center mr-30">
                <div class="author-img">
                  <img src="<?= base_url();?>assets/images/testimonials/thumbs/7.jpg" alt="thumb">
                </div>
                <div>
                  <h4 class="author-title">Jane Winston</h4>
                  <span class="author-desc">Our Founder</span>
                </div>
                <img src="<?= base_url();?>assets/images/about/singnture2.png" class="author-singnture" alt="singnture">
              </div>
            </div>
          </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.About Layout 2 -->

    <!-- ========================
     Banner Layout 8
    =========================== -->
    <section class="banner-layout8 bg-primary">
      <div class="top-shape"></div>
      <div class="container-fluid">
        <div class="row">
          <div class="col-12 col-xl-5 banner-content">
            <div class="banner-text">
              <div class="heading-layout2 heading-light">
                <h3 class="heading-title" style="font-size:22px">As NORTHWEST INDIANA'S LEADING DRUG TESTING PROVIDER we offer quality and professional testing services.</h3>
                <p class="heading-desc font-weight-bold mb-40"> Our Testing services are accurate, affordable, confidential and guaranteed results.   we're committed to providing a superior level of service for our clients. </p> 
                <p class="heading-desc font-weight-bold mb-40">we feel that we are unmatched in customer care and we work hard daily to ensure your experience with our staff is always pleasant. 

                </p>

                <p class="heading-desc font-weight-bold mb-40">We value integrity, professionalism and confidentiality, while guaranteeing our client’s needs are first and foremost.</p>
              </div>
              <div class="d-flex flex-wrap mb-90">
                <a href="<?= base_url('about-us');?>" class="btn btn-white btn-white-style2 mr-30">
                  <span>Looking for More Info!</span> <i class="icon-arrow-right"></i>
                </a>
                <a href="<?= base_url('contact');?>" class="btn btn-light btn-outlined">Contact Us</a>
              </div>
              <div class="fancybox-layout2 fancybox-light">
                <div class="fancybox-item">
                 
                </div><!-- /.fancybox-item -->
                <div class="fancybox-item">
                 
                </div><!-- /.fancybox-item -->
              </div><!-- /.fancybox-layout2 -->
            </div><!-- /.banner-text -->
          </div><!-- /.col-xl-5 -->
          <div class="col-12 col-xl-7 d-flex align-items-center pl-50 pr-0">
            <div class="banner-img">
              <div class="bg-img">
                <img src="<?= base_url();?>assets/images/banners/8.jpg" alt="backgrounds">
              </div>
            </div>
            <div class="banner-shape"></div>
          </div><!-- /.col-xl-7 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.Banner Layout8 -->

    <!-- ========================
        Services Layout 4
    =========================== -->
    <section class="services-layout4 pb-0">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3">
            <div class="heading-layout2 text-center mb-50">
              <h2 class="heading-subtitle">Find the Right Test for Your Needs!</h2>
              <h3 class="heading-title">Providing the Diverse Needs of Your Patient Community</h3>
            </div>
          </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
        <div class="row">
          <div class="col-12">
            <div class="slick-carousel"
              data-slick='{"slidesToShow": 3, "slidesToScroll": 1, "autoplay": true, "arrows": false, "dots": true, "responsive": [ {"breakpoint": 1100, "settings": {"slidesToShow": 2}},{"breakpoint": 992, "settings": {"slidesToShow": 1}}, {"breakpoint": 767, "settings": {"slidesToShow": 1}}, {"breakpoint": 480, "settings": {"slidesToShow": 1}}]}'>
              <!-- service item #1 -->
              <div class="service-item">
                <div class="service-body">
                  <div class="service-icon">
                    <i class="icon-education4 icon-item"></i>
                    <i class="icon-education4 icon-item"></i>
                  </div>
                  <h4 class="service-title">
                    <a href="<?= base_url('services/drug-testing');?>">Drug testing</a>
                  </h4>
                </div><!-- /.service-body -->
                <div class="service-img">
                  <img src="<?= base_url();?>assets/img/drug.jpg" alt="service">
                </div><!-- /.service-img -->
                <a href="<?= base_url('services/drug-testing');?>" class="service-more">
                  <svg class="service-more-svg">
                    <path stroke-width="2px" stroke="white" fill="transparent"
                      d="M105.000,82.843 L104.995,82.843 C104.982,87.968 102.169,92.700 97.606,95.262 L62.390,115.041 C57.816,117.610 52.181,117.610 47.607,115.041 L12.390,95.262 C7.827,92.700 5.014,87.968 5.001,82.843 L5.000,82.843 L5.000,82.821 C5.000,82.817 4.999,82.812 4.999,82.808 L5.000,82.808 L5.000,39.148 L4.992,39.148 C4.992,34.010 7.810,29.262 12.383,26.694 L47.600,6.915 C52.174,4.346 57.809,4.346 62.383,6.915 L97.599,26.694 C102.157,29.253 104.967,33.977 104.987,39.094 L105.000,39.094 L105.000,82.843 Z">
                    </path>
                  </svg>
                  <i class="plus-icon">+</i>
                </a>
              </div><!-- /.service-item -->
              <!-- service item #2 -->
              <div class="service-item">
                <div class="service-body">
                  <div class="service-icon">
                   <i class='fas fa-virus' style='font-size:70px'></i>
                  </div>
                  <h4 class="service-title">
                    <a href="<?= base_url('services/covid-19-testing');?>">Covid 19 testing</a>
                  </h4>
                </div><!-- /.service-body -->
                <div class="service-img">
                  <img src="<?= base_url();?>assets/img/covid.jpg" alt="service">
                </div><!-- /.service-img -->
                <a href="<?= base_url('services/covid-19-testing');?>" class="service-more">
                  <svg class="service-more-svg">
                    <path stroke-width="2px" stroke="white" fill="transparent"
                      d="M105.000,82.843 L104.995,82.843 C104.982,87.968 102.169,92.700 97.606,95.262 L62.390,115.041 C57.816,117.610 52.181,117.610 47.607,115.041 L12.390,95.262 C7.827,92.700 5.014,87.968 5.001,82.843 L5.000,82.843 L5.000,82.821 C5.000,82.817 4.999,82.812 4.999,82.808 L5.000,82.808 L5.000,39.148 L4.992,39.148 C4.992,34.010 7.810,29.262 12.383,26.694 L47.600,6.915 C52.174,4.346 57.809,4.346 62.383,6.915 L97.599,26.694 C102.157,29.253 104.967,33.977 104.987,39.094 L105.000,39.094 L105.000,82.843 Z">
                    </path>
                  </svg>
                  <i class="plus-icon">+</i>
                </a>
              </div><!-- /.service-item -->
              <!-- service item #3 -->
              <div class="service-item">
                <div class="service-body">
                  <div class="service-icon">
                    <i class="icon-search icon-item"></i>
                    <i class="icon-search icon-item"></i>
                  </div>
                  <h4 class="service-title">
                    <a href="<?= base_url('services/background-checks');?>">Background checks</a>
                  </h4>
                </div><!-- /.service-body -->
                <div class="service-img">
                  <img src="<?= base_url();?>assets/img/background.jpg" alt="service">
                </div><!-- /.service-img -->
                <a href="<?= base_url('services/background-checks');?>" class="service-more">
                  <svg class="service-more-svg">
                    <path stroke-width="2px" stroke="white" fill="transparent"
                      d="M105.000,82.843 L104.995,82.843 C104.982,87.968 102.169,92.700 97.606,95.262 L62.390,115.041 C57.816,117.610 52.181,117.610 47.607,115.041 L12.390,95.262 C7.827,92.700 5.014,87.968 5.001,82.843 L5.000,82.843 L5.000,82.821 C5.000,82.817 4.999,82.812 4.999,82.808 L5.000,82.808 L5.000,39.148 L4.992,39.148 C4.992,34.010 7.810,29.262 12.383,26.694 L47.600,6.915 C52.174,4.346 57.809,4.346 62.383,6.915 L97.599,26.694 C102.157,29.253 104.967,33.977 104.987,39.094 L105.000,39.094 L105.000,82.843 Z">
                    </path>
                  </svg>
                  <i class="plus-icon">+</i>
                </a>
              </div><!-- /.service-item -->
              <!-- service item #4 -->
              <div class="service-item">
                <div class="service-body">
                  <div class="service-icon">
                    <i class="icon-biology6 icon-item"></i>
                    <i class="icon-biology6 icon-item"></i>
                  </div>
                  <h4 class="service-title">
                    <a href="<?= base_url('services/dna-testing');?>"> DNA Testing</a>
                  </h4>
                </div><!-- /.service-body -->
                <div class="service-img">
                  <img src="<?= base_url();?>assets/img/dna.jpg" alt="service">
                </div><!-- /.service-img -->
                <a href="<?= base_url('services/dna-testing');?>" class="service-more">
                  <svg class="service-more-svg">
                    <path stroke-width="2px" stroke="white" fill="transparent"
                      d="M105.000,82.843 L104.995,82.843 C104.982,87.968 102.169,92.700 97.606,95.262 L62.390,115.041 C57.816,117.610 52.181,117.610 47.607,115.041 L12.390,95.262 C7.827,92.700 5.014,87.968 5.001,82.843 L5.000,82.843 L5.000,82.821 C5.000,82.817 4.999,82.812 4.999,82.808 L5.000,82.808 L5.000,39.148 L4.992,39.148 C4.992,34.010 7.810,29.262 12.383,26.694 L47.600,6.915 C52.174,4.346 57.809,4.346 62.383,6.915 L97.599,26.694 C102.157,29.253 104.967,33.977 104.987,39.094 L105.000,39.094 L105.000,82.843 Z">
                    </path>
                  </svg>
                  <i class="plus-icon">+</i>
                </a>
              </div><!-- /.service-item -->
              <!-- service item #5 -->
            
            </div><!-- /.slick-carousel -->
          </div><!-- /.col-12 -->
        </div><!-- /.row -->
        <div class="cat-area pt-50 pb-50 mt-60 border-top">
          <div class="row align-items-center">
            <div class="col-md-12 col-lg-6 col-xl-5">
              <p class="font-weight-bold">Whether you are a provider or patient, when you need trusted information to
                make
                confident health
                decisions, consider us.
                <a href="#" class="color-secondary underlined-text-secondary font-weight-bold">Our Specialty Areas</a>
              </p>
            </div><!-- /.col-xl-5 -->
            <div class="col-md-12 col-lg-6 col-xl-6 offset-xl-1 d-flex flex-wrap justify-content-xl-end">
              <a href="services.php" class="btn btn-primary btn-xl mr-30">
                <span>Tests and Services</span>
                <i class="icon-arrow-right"></i>
              </a>
              <div class="contact-phone d-flex align-items-center">
                <div class="phone-icon mr-20">
                  <i class="icon-phone icon-item"></i>
                </div>
                <span class="fz-14">Contact our friendly staff or call us any time 01061245741</span>
              </div>
            </div><!-- /.col-xl-6 -->
          </div><!-- /.row -->
        </div><!-- /.Call to action Area -->
      </div><!-- /.container -->
    </section><!-- /.Services Layout 4 -->



      <!-- ======================
       Banner Layout 7
      ========================= -->
      <section class="banner-layout7 py-0">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-4 order-2-md">
              <div class="banner-img"><img src="<?= base_url();?>assets/img/background2.jpg" class="w-100" alt="banner"></div>
            </div><!-- /.col-lg-4 -->
            <div class="col-sm-12 col-md-12 col-lg-8 order-1-md">
              <div class="banner-content">
                <div class="heading-layout2 mb-50">
                  <h2 class="heading-title">Why People Love Us!</h2>
                </div>
                <div class="testimonials-layout3">
                  <div class="testimonials-container">
                    <div class="slider-has-navs">
                      <!-- Testimonial #1 -->
                      <div class="testimonial-item">
                        <h3 class="testimonial-title">They have cultivated a loyal following of functional and
                          integrative medicine professionals, unified by a desire to prevent disease and attain health.
                          They alued partners in providing only high quality testing to help us achieve clinical results
                          faster .
                        </h3>
                      </div><!-- /. testimonial-item -->
                      <!-- Testimonial #2 -->
                      <div class="testimonial-item">
                        <h3 class="testimonial-title">Their doctors include highly qualified practitioners who come
                          from
                          a
                          range of backgrounds and bring with them a diversity of skills and special interests. They
                          also
                          have
                          registered nurses on staff who are available to triage any urgent matters
                        </h3>
                      </div><!-- /. testimonial-item -->
                    </div><!-- /.slick-carousel -->
                    <div class="slider-nav-thumbnails">
                      <div class="testimonial-meta d-flex align-items-center">
                        <div class="testimonial-thmb">
                          <img src="<?= base_url();?>assets/images/testimonials/thumbs/3.jpg" alt="thumb">
                        </div>
                        <div>
                          <h4 class="testimonial-meta-title">Anna Mudson</h4>
                          <p class="testimonial-meta-desc">Optime Labs</p>
                        </div>
                      </div>
                      <div class="testimonial-meta d-flex align-items-center">
                        <div class="testimonial-thmb">
                          <img src="<?= base_url();?>assets/images/testimonials/thumbs/1.jpg" alt="thumb">
                        </div>
                        <div>
                          <h4 class="testimonial-meta-title">Sami Wade</h4>
                          <p class="testimonial-meta-desc">Medcity Labs</p>
                        </div>
                      </div>
                    </div><!-- /.slider-nav-thumbnails -->
                  </div><!-- /.testimonials-container -->
                </div><!-- /.testimonials-layout3 -->
              </div><!-- /.banner-content -->
            </div><!-- /.col-lg-7 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </section><!-- /.Banner Layout 7 -->
    </div>

   