 <section class="page-title-layout3 page-title-light text-center pb-0 bg-overlay bg-parallax">
  <div class="bg-img"><img src="<?= base_url();?>assets/img/background3.jpg" alt="background"></div>
  <div class="container">
    <div class="row">
      <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6 offset-xl-3">
        <div class="pagetitle-categorey"><a href="#">Services</a> </div>
        <h1 class="pagetitle-heading">DNA testing
        </h1>

      </div><!-- /.col-xl-6 -->
    </div><!-- /.row -->
  </div><!-- /.container -->
  <div class="breadcrumb-area">
    <div class="container">
      <nav>
        <ol class="breadcrumb justify-content-center mb-0">
          <li class="breadcrumb-item">
            <a href="<?= base_url()?>"><i class="icon-home"></i> <span>Home</span></a>
          </li>
          <li class="breadcrumb-item">
            <a href="<?= base_url('services');?>">Services</a>
          </li>
          <li class="breadcrumb-item active" aria-current="page">DNA testing
          </li>
        </ol>
      </nav>
    </div><!-- /.container -->
  </div><!-- /.breadcrumb-area -->
</section><!-- /.page-title -->


<section class=" pb-80">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-lg-8 offset-lg-2">
        <div class="text-block mb-50">
          
          

                  <div class="row text-justify">
            <div class="col-lg-9 ">
              <p class="text-block-desc mb-20 text-justify">
           DNA testing is a process that analyzes a person's DNA to determine their genetic makeup. There are several different types of DNA tests, including: </p>
           <ul>
            <li>Paternity testing: Compares the DNA of a child and a man to determine if the man is the child's biological father. </li>

            <li>Maternity testing: Compares the DNA of a child and a woman to determine if the woman is the child's biological mother.</li>

            <li>Sibling testing: Compares the DNA of two or more people to determine if they are full siblings, half siblings, or not related.</li>

            <li>Ancestry testing: Analyzes a person's DNA to determine their ethnic and geographic ancestry.</li>

            <li>Forensic testing: Compares DNA samples from a crime scene with those from a suspect to determine if they match.</li>

            <li>Medical genetic testing: Analyzes a person's DNA to identify genetic risks for certain diseases or to determine if they are a carrier of a genetic disorder.</li>
          </ul>

            </div>
            <div class="col-lg-3 text-center">
              <img src="<?= base_url();?>assets/img/6.png" class="img-fluid" width="90%"> 
              <br>

             <img src="<?= base_url();?>assets/img/5.png" class="img-fluid" width="90%">
          

            </div>

          
           <div class="col-lg-12">
             <p class="text-block-desc mb-20  text-justify">
             The accuracy of DNA testing is high, and it is widely accepted as a reliable form of identification and evidence in courts
             <br><br>
               Why take a genetic test? Whether you’re wondering if you’re the father of a child, not sure who your biological mother is, or you just want to check the percentage of a sibling, a genetic test at Arkham Laboratory Collections can help give you answers!
        </p>
            </p>
          </div>
        </div>

      </div><!-- /.text-block -->
    </div><!-- /.col-lg-8 -->
  </div><!-- /.row -->
</div><!-- /.container -->
</section>